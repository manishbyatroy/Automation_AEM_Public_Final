(function publishPage() {         
    let menuButton = document.getElementsByClassName('js-editor-PageInfo-closePopover cq-authoring-actions-quickpublish-activator coral3-Button coral3-Button--secondary');
    let clickFunc = menuButton[0];
    clickFunc.click();   
}
)()